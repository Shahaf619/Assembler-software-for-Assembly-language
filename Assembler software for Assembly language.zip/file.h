
#define FIRST_FILE 1
#define OBJECT_END ".ob"
#define ASSEMBLY_END ".as"
#define EXTERNAL_END ".ext"
#define ENTRY_END ".ent"
#define CREATE_FILE "w"
#define READ_FILE "r"
